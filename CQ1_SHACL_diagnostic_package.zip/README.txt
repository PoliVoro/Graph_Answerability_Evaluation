CQ1 diagnostic SHACL candidate shapes (MSS, November 2026)

1. CQ1_candidate_SHACL_warnings.ttl uses W3C SHACL-SPARQL (not SHACL-AF rules).
   - 000 (no B / no U / no condition): sh:Warning
   - 001 (no B / no U / condition): sh:Info
   - other six combinations: no validation finding

2. CQ1_eight_outcomes.rq classifies every Level C record using three Boolean
   signals, yielding 8 independent combinations. The output does not claim that
   a retrievable Level B link is the original belonging, nor that no explicit
   unknown flag means the original object is known.

3. The sample namespaces for crm:, mss:, msst: must be checked against
   the active data graph. In particular the official CQ1 semantic path must
   be used for retrieval of a Level B relationship. This template assumes
   crm:P46i_forms_part_of with a parent mss:has_type msst:level_b.

4. This is deliberately diagnostic: a recorded condition can be meaningful
   without explaining why a parent relationship is absent. None of the
   alerts asserts that an art-historical record is wrong.

5. Counts from the 224-distinct-Level-C CSV snapshot (not a runtime SHACL test):
   B U C  count
   1 1 1     5
   1 1 0     6
   1 0 1    52
   1 0 0    91
   0 1 1     3
   0 1 0     7
   0 0 1    21
   0 0 0    39
   total     224

6. Implementation and operational validation on the live MSS RDF graph remain
   future work; the classification and warnings have not been validated on it.

7. SHACL 1.0 Recommendation treats any validation result (including sh:Info or
   sh:Warning) as a non-conforming report. Consumers should interpret severity
   rather than the Boolean sh:conforms as a claim about historical correctness.

8. Synthetic tests cover the eight Boolean combinations and additional controls
   for an unlabelled E80 event and an E80 with P112_diminished. These are not
   equivalent to running the shapes on the live project graph.
